package com.example.projets4.data;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import com.example.projets4.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.springframework.security.crypto.bcrypt.BCrypt;

public class Register extends AppCompatActivity implements View.OnClickListener {

    private DatabaseHelper connexionBD;
    FloatingActionButton register;
    EditText username, password, email;
    String user, pass, mail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        this.connexionBD = new DatabaseHelper(this);

        register = findViewById(R.id.register);
        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        email = findViewById(R.id.email);

        register.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

        Thread t = new Thread() {
            @Override
            public void run() {

                user = username.getText().toString();
                pass = password.getText().toString();
                mail = email.getText().toString();
                pass = BCrypt.hashpw(pass, BCrypt.gensalt());

                if (verifMembreExiste(user)) {
                    runOnUiThread(new Runnable() {
                        public void run() {
                            Toast.makeText(getApplicationContext(), "L'utilisateur existe déjà", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
                else creerMembre(user,pass,mail);
            }
        };
        t.start();
    }

    public boolean verifMembreExiste(String name) {
        boolean retour = true;
        Cursor res = connexionBD.getData("select * from Utilisateur where user_login = '" + name + "'");
        if (res.getCount()==0) {
            retour = false;
            res.close();
        }
        return retour;
    }

    public void creerMembre(String name, String password, String mail) {
        if (connexionBD.insertUtilisateur(name, password, mail)) {
            runOnUiThread(new Runnable() {
                public void run() {
                    Toast.makeText(getApplicationContext(), "Vous vous êtes inscris", Toast.LENGTH_SHORT).show();
                }
            });
            Cursor res = connexionBD.getData("select * from Utilisateur where user_login = '" + name +"'");
            if (res.moveToNext()) {
                int id = res.getInt(0);
                Intent intent = new Intent(this, Langue.class);
                User session = new User(name, password, mail, id);
                intent.putExtra("session", session);
                startActivity(intent);
            }
        }
    }
}
