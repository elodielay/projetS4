package com.example.projets4.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "ProjetS4.db";

    public static final String TABLE_USER = "Utilisateur";
    public static final String USER_COL_1 = "user_id";
    public static final String USER_COL_2 = "user_login";
    public static final String USER_COL_3 = "user_mail";
    public static final String USER_COL_4 = "user_mdp";

    public static final String TABLE_THEME = "Theme";
    public static final String THEME_COL_1 = "theme_id";
    public static final String THEME_COL_2 = "theme_nom";
    public static final String THEME_COL_3 = "langue_id";
    public static final String THEME_COL_4 = "user_id";

    public static final String TABLE_MOT = "Mot";
    public static final String MOT_COL_1 = "mot_id";
    public static final String MOT_COL_2 = "mot";
    public static final String MOT_COL_3 = "trad";
    public static final String MOT_COL_4 = "theme_id";

    public final String TABLE_LANGUE = "Langue";
    public static final String LANGUE_COL_1 = "langue_id";
    public static final String LANGUE_COL_2 = "langue";


    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("create table "  + TABLE_USER + " (USER_ID INTEGER PRIMARY KEY AUTOINCREMENT, USER_LOGIN VARCHAR, USER_MAIL VARCHAR, USER_MDP VARCHAR) ");
        sqLiteDatabase.execSQL("create table "  + TABLE_THEME + " (THEME_ID INTEGER PRIMARY KEY AUTOINCREMENT, THEME_NOM VARCHAR, LANGUE_ID INTEGER, USER_ID INTEGER) ");
        sqLiteDatabase.execSQL("create table "  + TABLE_MOT + " (MOT_ID INTEGER PRIMARY KEY AUTOINCREMENT, MOT VARCHAR, TRAD VARCHAR, THEME_ID INTEGER)");
        sqLiteDatabase.execSQL("create table "  + TABLE_LANGUE + " (LANGUE_ID INTEGER PRIMARY KEY AUTOINCREMENT, LANGUE VARCHAR)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldV, int newV) {
        onCreate(sqLiteDatabase);
    }

    public boolean insertUtilisateur(String name, String password, String mail) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(USER_COL_2, name);
        contentValues.put(USER_COL_3, mail);
        contentValues.put(USER_COL_4, password);
        long result = db.insert(TABLE_USER, null, contentValues);
        if (result == -1) return false;
        else return true;
    }

    public boolean insertTheme(String name, int langue, int idUser) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(THEME_COL_2, name);
        contentValues.put(THEME_COL_3, langue);
        contentValues.put(THEME_COL_4, idUser);
        long result = db.insert(TABLE_THEME, null, contentValues);
        if (result == -1) return false;
        else return true;
    }

    public boolean insertMot(String mot, String trad, int idTheme) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(MOT_COL_2, mot);
        contentValues.put(MOT_COL_3, trad);
        contentValues.put(MOT_COL_4, idTheme);
        long result = db.insert(TABLE_MOT, null, contentValues);
        if (result == -1) return false;
        else return true;
    }

    public Cursor getData(String requete) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery(requete, null);
        return res;
    }

    public int delete(String tableName, String n, String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(tableName, n + " = ?", new String[] {id});
    }

    public boolean insertLangue() {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(THEME_COL_2, "anglais");
        contentValues.put(THEME_COL_2, "chinois");
        contentValues.put(THEME_COL_2, "espagnol");
        contentValues.put(THEME_COL_2, "roumain");
        contentValues.put(THEME_COL_2, "arabe");
        contentValues.put(THEME_COL_2, "coréen");
        long result = db.insert(TABLE_THEME, null, contentValues);
        if (result == -1) return false;
        else return true;
    }

    public boolean update(String username, String id, String pwd, String mail) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(USER_COL_1, id);
        contentValues.put(USER_COL_2, username);
        contentValues.put(USER_COL_3, mail);
        contentValues.put(USER_COL_4, pwd);
        db.update(TABLE_USER, contentValues, USER_COL_1 + " = ?", new String[] {id});
        return true;
    }

    public boolean updateMot(String nomMot, String nomTrad, String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(MOT_COL_2, nomMot);
        contentValues.put(MOT_COL_3, nomTrad);
        db.update(TABLE_MOT, contentValues, MOT_COL_1 + " = ?", new String[] {id});
        return true;
    }
}
