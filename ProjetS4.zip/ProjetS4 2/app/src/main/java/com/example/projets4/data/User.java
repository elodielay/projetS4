package com.example.projets4.data;

import android.content.SharedPreferences;
import android.os.Parcel;
import android.os.Parcelable;

public class User implements Parcelable {

    private String nom, mdp, mail;
    private int id;

    public User(String nom, String mdp, String mail, int id) {
        this.nom=nom;
        this.mdp=mdp;
        this.mail = mail;
        this.id = id;
    }

    protected User(Parcel in) {
        nom = in.readString();
        mdp = in.readString();
        mail = in.readString();
        id = in.readInt();
    }

    public static final Creator<User> CREATOR = new Creator<User>() {
        @Override
        public User createFromParcel(Parcel in) {
            return new User(in);
        }

        @Override
        public User[] newArray(int size) {
            return new User[size];
        }
    };

    public String getNom() {
        return this.nom;
    }

    public void setNom(String nom) {
        this.nom=nom;
    }

    public String getMdp() {
        return this.mdp;
    }

    public void setMdp(String mdp) {
        this.mdp=mdp;
    }

    public String getMail() {
        return this.mail;
    }

    public void setMail(String mail) {
        this.mail=mail;
    }

    public int getId() {
        return this.id;
    }

    public void setId(int id) {
        this.id=id;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(nom);
        dest.writeString(mdp);
        dest.writeString(mail);
        dest.writeInt(id);
    }
}
