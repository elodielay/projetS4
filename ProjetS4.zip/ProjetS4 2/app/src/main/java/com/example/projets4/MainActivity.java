package com.example.projets4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.projets4.data.Langue;
import com.example.projets4.data.Register;
import com.example.projets4.data.User;
import com.example.projets4.ui.login.LoginActivity;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder()
                .detectDiskReads()
                .detectDiskWrites()
                .detectNetwork()
                .penaltyLog()
                .build());

        StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder()
                .detectLeakedSqlLiteObjects()
                .penaltyLog()
                .penaltyDeath()
                .build());

        sharedPreferences = getBaseContext().getSharedPreferences("user", MODE_PRIVATE);

        if (sharedPreferences.contains("user_id") && sharedPreferences.contains("user_name") && sharedPreferences.contains("user_mdp") && sharedPreferences.contains("user_mail")) {
            User session = new User(sharedPreferences.getString("user_name",null), sharedPreferences.getString("user_mail", null), sharedPreferences.getString("user_mdp",null), sharedPreferences.getInt("user_id", 0));
            Intent intent = new Intent(this, Langue.class);
            intent.putExtra("session", session);
            startActivity(intent);
        }

        Button boutonInscription = findViewById(R.id.buttonInscription);
        Button boutonConnexion = findViewById(R.id.buttonConnexion);

        boutonInscription.setOnClickListener(this);
        boutonConnexion.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

        switch(v.getId()) {

            case R.id.buttonInscription :
                startActivity(new Intent(MainActivity.this, Register.class));
                break;

            case R.id.buttonConnexion :
                startActivity(new Intent(MainActivity.this, LoginActivity.class));
                break;
        }
    }
}

