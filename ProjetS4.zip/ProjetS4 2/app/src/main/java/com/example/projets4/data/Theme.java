package com.example.projets4.data;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.projets4.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class Theme extends AppCompatActivity implements View.OnClickListener {

    private DatabaseHelper connexionBD;
    private int idTheme;
    private boolean boutonAjouterClicker;
    private boolean boutonModifierClicker;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_theme);

        Intent intent = getIntent();

        if (intent != null) {
            idTheme = intent.getIntExtra("idTheme", 1);
        }

        this.connexionBD = new DatabaseHelper(this);

        FloatingActionButton ajouter = findViewById(R.id.add);
        ajouter.setOnClickListener(this);

        boutonModifierClicker = false;

        FloatingActionButton questions = findViewById(R.id.question);
        questions.setOnClickListener(this);
        afficheListeMots();


        boutonAjouterClicker = false;

    }

    public void afficheListeMots()  {

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
                    @Override
                    public void run() {

                        Cursor res = connexionBD.getData("select * from Mot");

                        while (res.moveToNext()) {
                           // System.out.println("mot" + res.getString(2));
                            //ystem.out.println("trad" + res.getString(3));

                            ajouterMot(res.getString(2), res.getString(3));
                        }
                        res.close();

                    }

                });
            }
        }, 100);

    }


    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.add:
                EditText e = new EditText(this);
                e.setHint("Mot");
                EditText trad = new EditText(this);
                trad.setHint("Traduction");
                Button b = new Button(this);
                b.setText("ok");
                TableLayout layout = findViewById(R.id.themesbis);

                layout.addView(e);
                layout.addView(trad);
                layout.addView(b);

                    b.setOnClickListener(new View.OnClickListener() {

                        @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
                        @Override
                        public void onClick(View view) {

                            String nomActivite = e.getText().toString();
                            String nomTrad = trad.getText().toString();

                            System.out.println(nomActivite);
                            System.out.println(nomTrad);



                            Thread t = new Thread() {
                                @Override
                                public void run() {

                                   connexionBD.insertMot(nomActivite, nomTrad, idTheme);
                                   runOnUiThread(new Runnable() {
                                            public void run() {
                                                Toast.makeText(getApplicationContext(), "Le mot " + nomActivite + " a été ajouté !", Toast.LENGTH_SHORT).show();
                                            }
                                        });

                                }
                            };

                            t.start();
                            ajouterMot(nomActivite, nomTrad);
                            layout.removeView(e);
                            layout.removeView(trad);
                            layout.removeView(b);

                        }

                    });

                break;

            case R.id.question :
                Intent intent = new Intent(Theme.this, Questions.class);
                intent.putExtra("idTheme", idTheme);
                startActivity(intent);
                break;

        }

    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    public void ajouterMot (String nomMot, String trad) {


        TextView mot = new TextView(getApplicationContext());
        mot.setText(nomMot);
        mot.setTextSize(20);

        TextView traduc = new TextView(getApplicationContext());
        traduc.setText(trad);
        traduc.setTextSize(18);

        Button supprimer = new Button(getApplicationContext());
        supprimer.setText("supprimer");
        supprimer.setHeight(60);
        supprimer.setWidth(20);

        Button modifier = new Button(getApplicationContext());
        modifier.setText("modifier");
        supprimer.setHeight(60);
        supprimer.setWidth(20);

        EditText nouveauMot = new EditText(getApplicationContext());
        //nouveauMot.setHint(res.getString(2));

        EditText nouveauTrad = new EditText(getApplicationContext());
        //nouveauMot.setHint(res.getString(3));

        Button valider = new Button(getApplicationContext());
        valider.setText("ok");
        supprimer.setHeight(20);
        supprimer.setWidth(20);

        TableLayout layout = findViewById(R.id.themesbis);
        TableLayout layout2 = findViewById(R.id.supprimerbis);
        TableLayout layout3 = findViewById(R.id.modifier);
        TableLayout layout4 = findViewById(R.id.traduction);

        mot.setId(layout.getChildCount());


        mot.setPadding(0, 0, 0, 0);
        traduc.setPadding(0,0,0,0);
        supprimer.setPadding(0, 0, 0, 0);
        modifier.setPadding(0, 0, 0, 0);
        nouveauMot.setPadding(0, 0, 0, 0);
        nouveauTrad.setPadding(0, 0, 0, 0);
        valider.setPadding(0, 0, 0, 0);

        supprimer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Thread supp = new Thread() {
                    @Override
                    public void run() {
                        System.out.println("mot " +mot.getText().toString());
                        connexionBD.delete("Mot", "mot", mot.getText().toString());

                        //tester la suppression
                        Cursor res = connexionBD.getData("select * from Mot");

                        while (res.moveToNext()) {
                            System.out.println(res.getString(2));
                        }

                    }

                };

                runOnUiThread(new Runnable() {
                    public void run() {
                        //Toast.makeText(getApplicationContext(), "Le mot " + nomMot + " a été supprimé !", Toast.LENGTH_SHORT).show();
                    }
                });
                supp.start();
                layout.removeView(mot);
                layout4.removeView(traduc);
                layout2.removeView(supprimer);
                layout3.removeView(modifier);
                layout.removeView(valider);
                layout.removeView(nouveauMot);
                layout.removeView(nouveauTrad);
            }
        });

        modifier.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                        if (!boutonModifierClicker) {
                            nouveauMot.setHint("Mot ");
                            nouveauTrad.setHint("Traduction");

                            nouveauMot.setId(mot.getId());

                            layout.addView(nouveauMot, nouveauMot.getId());
                            layout.addView(nouveauTrad);
                            layout.addView(valider);

                            boutonModifierClicker = true;
                            valider.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    Thread mod = new Thread() {
                                        @Override
                                        public void run() {
                                            Cursor res = connexionBD.getData("select * from Mot where mot = '" + nomMot + "' and trad = '" + trad);
                                            if (res.moveToNext()) {
                                                connexionBD.updateMot(nouveauMot.getText().toString(), nouveauTrad.getText().toString(), String.valueOf(res.getInt(0)));
                                            }
                                        }
                                    };
                                    mod.start();
                                    layout.removeView(nouveauMot);
                                    layout.removeView(nouveauTrad);
                                    layout.removeView(valider);
                                    mot.setText(nouveauMot.getText().toString());
                                    traduc.setText(nouveauTrad.getText().toString());
                                    layout.addView(mot, nouveauMot.getId());
                                    layout.addView(traduc);
                                }
                            });
                        }
                        else if (boutonModifierClicker) {
                            layout.removeView(nouveauMot);
                            layout.removeView(nouveauTrad);
                            layout.removeView(valider);

                            layout.removeViewAt(mot.getId());
                            layout.addView(mot, mot.getId());
                            //layout.addView(traduc);
                            boutonModifierClicker=false;
                        }
                    }



        });

        layout.addView(mot);
        layout4.addView(traduc);
        layout3.addView(modifier);
        layout2.addView(supprimer);


    }
}



