package com.example.projets4.data;

import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.projets4.MainActivity;
import com.example.projets4.R;

public class Langue extends AppCompatActivity implements View.OnClickListener{

    private Button buttonAnglais, buttonArabe, buttonChinois, buttonEspagnol, buttonCoreen, buttonRoumain, addLanguage;
    private User session;
    private DatabaseHelper connexion;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        this.addLanguage = findViewById(R.id.addLanguage);

        this.buttonAnglais = findViewById(R.id.anglais);
        this.buttonArabe = findViewById(R.id.arabe);
        this.buttonChinois = findViewById(R.id.chinois);
        this.buttonEspagnol = findViewById(R.id.espagnol);
        this.buttonCoreen = findViewById(R.id.coreen);
        this.buttonRoumain = findViewById(R.id.roumain);

        this.buttonAnglais.setOnClickListener(this);
        this.buttonArabe.setOnClickListener(this);
        this.buttonChinois.setOnClickListener(this);
        this.buttonEspagnol.setOnClickListener(this);
        this.buttonCoreen.setOnClickListener(this);
        this.buttonRoumain.setOnClickListener(this);

        this.addLanguage.setOnClickListener(this);

        Intent intent = getIntent();

        if (intent != null){
            session = intent.getParcelableExtra("session");

            if (session != null){
                runOnUiThread(new Runnable() {
                    public void run() {
                        Toast.makeText(getApplicationContext(), session.getNom() + " est connecté", Toast.LENGTH_SHORT).show();
                    }
                });
                sharedPreferences = getBaseContext().getSharedPreferences("user", MODE_PRIVATE);
                sharedPreferences.edit().putString("user_name", session.getNom()).putString("user_mdp", session.getMdp()).putString("user_mail", session.getMail()).putInt("user_id", session.getId()).apply();
            }
        }

        connexion = new DatabaseHelper(this);
        connexion.insertLangue();

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_langue, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()) {
            case R.id.deconnexion :
                seDeconnecter();
                return true;
            case R.id.profil :
                Intent intent = new Intent(this, Profil.class);
                intent.putExtra("session", session);
                startActivity(intent);
                return true;
            default :
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onClick(View v) {

        Intent intent = new Intent(Langue.this, Themes.class);
        intent.putExtra("session", session);

        switch(v.getId()) {

            case R.id.addLanguage :
                Toast.makeText(this, "Ajoutez des langues au clavier", Toast.LENGTH_SHORT).show();
                intent = new Intent();
                intent.setComponent(new ComponentName("com.android.settings", "com.android.settings.Settings$LanguageAndInputSettingsActivity"));
                break;

            case R.id.anglais :
                Toast.makeText(this, "Vous avez choisi l'anglais", Toast.LENGTH_SHORT).show();
                intent.putExtra("langue",1);
                break;

            case R.id.arabe :
                Toast.makeText(this, "Vous avez choisi l'arabe", Toast.LENGTH_SHORT).show();
                intent.putExtra("langue",5);
                break;

            case R.id.chinois :
                Toast.makeText(this, "Vous avez choisi le chinois", Toast.LENGTH_SHORT).show();
                intent.putExtra("langue",2);
                break;

            case R.id.espagnol :
                Toast.makeText(this, "Vous avez choisi l'espagnol", Toast.LENGTH_SHORT).show();
                intent.putExtra("langue",3);
                break;

            case R.id.coreen :
                Toast.makeText(this, "Vous avez choisi le coréen", Toast.LENGTH_SHORT).show();
                intent.putExtra("langue",6);
                break;

            case R.id.roumain :
                Toast.makeText(this, "Vous avez choisi le roumain", Toast.LENGTH_SHORT).show();
                intent.putExtra("langue",4);
                break;

        }
        startActivity(intent);
    }

    public void seDeconnecter() {
        sharedPreferences.edit().clear().commit();
        startActivity(new Intent(this, MainActivity.class));
    }

}
