package com.example.projets4.data;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.projets4.MainActivity;
import com.example.projets4.R;

import org.springframework.security.crypto.bcrypt.BCrypt;

public class Profil extends AppCompatActivity {

    private User session;
    EditText username, mdp, mail;
    Button modify, supprimerCompte;
    private DatabaseHelper connexionBD;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profil);

        Intent intent = getIntent();

        if (intent != null) {
            session = intent.getParcelableExtra("session");
        }

        this.connexionBD = new DatabaseHelper(this);

        username = findViewById(R.id.usernameInfo);
        mdp = findViewById(R.id.passwordInfo);
        mail = findViewById(R.id.emailInfo);

        username.setText(session.getNom());
        mdp.setText(session.getMdp());
        mail.setText(session.getMail());

        supprimerCompte = findViewById(R.id.supprimerCompte);
        supprimerCompte.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Thread supp = new Thread() {
                    @Override
                    public void run() {
                        connexionBD.delete("Utilisateur", "user_id", String.valueOf(session.getId()));
                        SharedPreferences sharedPreferences = getBaseContext().getSharedPreferences("user", MODE_PRIVATE);
                        sharedPreferences.edit().clear().commit();
                        startActivity(new Intent(Profil.this, MainActivity.class));
                    }
                };
                supp.start();
            }
        });

        modify = findViewById(R.id.modify);
            modify.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Thread mod = new Thread() {
                        @Override
                        public void run() {
                            String user = username.getText().toString();
                            String pwd = mdp.getText().toString();
                            String email = mail.getText().toString();
                            pwd = BCrypt.hashpw(pwd, BCrypt.gensalt());
                            boolean isUpdate = connexionBD.updateUtilisateur(user, String.valueOf(session.getId()), pwd, email);
                            session.setNom(user);
                            session.setMdp(pwd);
                            session.setMail(email);

                            if (isUpdate) {
                                runOnUiThread(new Runnable() {
                                    public void run() {
                                        Toast.makeText(getApplicationContext(), "Les informations ont été modifiés", Toast.LENGTH_SHORT).show();
                                    }
                                });
                            }
                            Intent intent2 = new Intent(Profil.this, Langue.class);
                            intent2.putExtra("session", session);
                            startActivity(intent2);
                        }
                    };
                    mod.start();
                }
            });
    }
}
