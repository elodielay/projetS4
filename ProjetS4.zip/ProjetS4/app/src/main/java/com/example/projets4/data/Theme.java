package com.example.projets4.data;

import android.content.Intent;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.projets4.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class Theme extends AppCompatActivity implements View.OnClickListener {

    private DatabaseHelper connexionBD;
    private int idTheme;
    private boolean boutonAjouterClicker;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_theme);

        Intent intent = getIntent();

        if (intent != null) {
            idTheme = intent.getIntExtra("idTheme", 1);
        }

        this.connexionBD = new DatabaseHelper(this);

        FloatingActionButton ajouter = findViewById(R.id.add);
        ajouter.setOnClickListener(this);

        FloatingActionButton questions = findViewById(R.id.question);
        questions.setOnClickListener(this);
        afficheListeMots();

        boutonAjouterClicker = false;

    }

    public void afficheListeMots()  {

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
                    @Override
                    public void run() {
                    Cursor res = connexionBD.getData("select * from Mot where theme_id = " + idTheme);

                    while (res.moveToNext()) {
                        ajouterMot(res.getString(1));
                    }
                    res.close();
                    }
                });
            }
        }, 100);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.add:
                EditText e = new EditText(this);
                e.setHint("Mot");
                EditText trad = new EditText(this);
                trad.setHint("Traduction");
                Button b = new Button(this);
                b.setText("ok");
                TableLayout layout = findViewById(R.id.themesbis);

                    layout.addView(e);
                    layout.addView(trad);
                    layout.addView(b);

                    b.setOnClickListener(new View.OnClickListener() {

                        @Override
                        public void onClick(View view) {

                            String nomActivite = e.getText().toString();
                            String nomTrad = trad.getText().toString();

                            Thread t = new Thread() {
                                @Override
                                public void run() {

                                   connexionBD.insertMot(nomActivite, nomTrad, idTheme);
                                   runOnUiThread(new Runnable() {
                                            public void run() {
                                                Toast.makeText(getApplicationContext(), "Le mot " + nomActivite + " a été ajouté !", Toast.LENGTH_SHORT).show();
                                            }
                                        });

                                }
                            };

                            t.start();
                            ajouterMot(nomActivite);
                            layout.removeView(e);
                            layout.removeView(trad);
                            layout.removeView(b);

                        }

                    });

                break;

            case R.id.question :
                Intent intent = new Intent(Theme.this, Questions.class);
                intent.putExtra("idTheme", idTheme);
                startActivity(intent);
                break;

        }

    }

    public void ajouterMot (String nomMot) {

        TextView mot = new TextView(getApplicationContext());
        Button supprimer = new Button(getApplicationContext());
        supprimer.setText("supprimer");
        mot.setText(nomMot);
        TableLayout layout = findViewById(R.id.themesbis);
        TableLayout layout2 = findViewById(R.id.supprimerbis);
        mot.setPadding(0, 0, 0, 0);
        supprimer.setPadding(0, 0, 0, 0);

        supprimer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Thread supp = new Thread() {
                    @Override
                    public void run() {
                        connexionBD.delete("Mot", "mot", mot.getText().toString());
                    }

                };
                supp.start();
                layout.removeView(mot);
                layout2.removeView(supprimer);
            }
        });

        layout.addView(mot);
        layout2.addView(supprimer);

    }
}



