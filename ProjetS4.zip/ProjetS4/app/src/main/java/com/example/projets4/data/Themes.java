package com.example.projets4.data;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;

import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.Toast;

import com.example.projets4.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class Themes extends AppCompatActivity implements View.OnClickListener {

    private User session;
    private DatabaseHelper connexionBD;
    private int langue;
    private boolean boutonAjouterClicker;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_themes);

        Intent intent = getIntent();

        if (intent != null) {
            session = intent.getParcelableExtra("session");
            langue = intent.getIntExtra("langue", 0);
        }

        this.connexionBD = new DatabaseHelper(this);

        FloatingActionButton ajouter = findViewById(R.id.buttonAjouterTheme);
        ajouter.setOnClickListener(this);

        afficheListeThemes();

        boutonAjouterClicker = false;
    }

    public void afficheListeThemes()  {

        Thread affiche = new Thread() {
            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void run() {
                Cursor res = connexionBD.getData("select * from Theme natural join Utilisateur where user_login = '" + session.getNom() + "' and langue_id = " + langue);
                if (res.getCount()!=0) {
                    while (res.moveToNext()) {
                        ajouterBouton(res.getString(1), res.getInt(0));
                    }
                }
                res.close();
            }
        };
        affiche.start();

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
                    case R.id.buttonAjouterTheme:
                        EditText e = new EditText(this);
                        e.setHint("Insérez nom thème");
                        Button b = new Button(this);
                        b.setBackgroundColor(Color.WHITE);
                        b.setText("ok");
                        TableLayout layout = findViewById(R.id.themes);
                            layout.addView(e);
                            layout.addView(b);

                            b.setOnClickListener(new View.OnClickListener() {
                                Integer id = 0;

                                @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
                                @Override
                                public void onClick(View view) {
                                    String nomActivite = e.getText().toString();
                                    Thread t = new Thread() {
                                        @Override
                                        public void run() {
                                            Cursor res = connexionBD.getData("select user_id from Utilisateur where user_login = '" + session.getNom() + "'");

                                             if (res.moveToNext()) {
                                                    id = res.getInt(0);
                                                    connexionBD.insertTheme(nomActivite, langue, id);

                                                    runOnUiThread(new Runnable() {
                                                        public void run() {
                                                            Toast.makeText(getApplicationContext(), "Le thème " + nomActivite + " a été ajouté !", Toast.LENGTH_SHORT).show();
                                                        }
                                                    });

                                                }

                                             res.close();

                                        }
                                    };

                                    t.start();
                                    ajouterBouton(nomActivite, id);
                                    layout.removeView(e);
                                    layout.removeView(b);

                                }
                            });

                        break;
                }

    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    public void ajouterBouton (String nomBouton, int idTheme) {

                Button b = new Button(getApplicationContext());
                Button supprimer = new Button(getApplicationContext());
                Drawable dr = getResources().getDrawable(R.drawable.recycle_bin);
                Bitmap bitmap = ((BitmapDrawable) dr).getBitmap();
                Drawable d = new BitmapDrawable(getResources(), Bitmap.createScaledBitmap(bitmap, 50, 50, true));
                supprimer.setBackground(d);
                b.setText(nomBouton);
                b.setBackgroundColor(Color.parseColor("#BBD1DC"));
                TableLayout layout = findViewById(R.id.themes);
                TableLayout layout2 = findViewById(R.id.supprimer);
                b.setPadding(0, 0, 0, 0);
                supprimer.setPadding(0, 0, 0, 0);
                b.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent(Themes.this, Theme.class);
                        intent.putExtra("idTheme", idTheme);
                        startActivity(intent);
                    }
                });

                supprimer.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Thread supp = new Thread() {
                            @Override
                            public void run() {
                                connexionBD.delete("Theme", "theme_nom", nomBouton);
                            }
                        };
                        runOnUiThread(new Runnable() {
                            public void run() {
                                Toast.makeText(getApplicationContext(), "Le thème " + nomBouton + " a été supprimé !", Toast.LENGTH_SHORT).show();
                            }
                        });
                        supp.start();
                        layout.removeView(b);
                        layout2.removeView(supprimer);
                    }
                });

                layout.addView(b);
                layout2.addView(supprimer);

    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(this, Langue.class);
        intent.putExtra("session", session);
        startActivity(intent);
    }
}
