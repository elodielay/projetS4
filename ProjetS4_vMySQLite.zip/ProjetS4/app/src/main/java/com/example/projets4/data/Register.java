package com.example.projets4.data;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import com.example.projets4.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.springframework.security.crypto.bcrypt.BCrypt;

public class Register extends AppCompatActivity implements View.OnClickListener {

    private DatabaseHelper connexionBD;
    private FloatingActionButton register;
    private EditText username;
    private EditText password;
    private EditText email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        this.connexionBD = new DatabaseHelper(this);

        this.register = findViewById(R.id.register);
        this.username = findViewById(R.id.username);
        this.password = findViewById(R.id.password);
        this.email = findViewById(R.id.email);

        register.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

        Thread t = new Thread() {
            @Override
            public void run() {

                String user = username.getText().toString();
                String pass = password.getText().toString();
                String mail = email.getText().toString();
                pass = BCrypt.hashpw(pass, BCrypt.gensalt());

                if (verifMembreExiste(user)) {
                    runOnUiThread(new Runnable() {
                        public void run() {
                            Toast.makeText(getApplicationContext(), "L'utilisateur existe déjà", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
                else creerMembre(user,pass,mail);
            }
        };
        t.start();
    }

    public boolean verifMembreExiste(String name) {
        boolean retour = true;
        Cursor res = connexionBD.getData("select * from Utilisateur where user_login = '" + name + "'");
        if (res.getCount()==0) {
            retour = false;
            res.close();
        }
        return retour;
    }

    public void creerMembre(String name, String password, String mail) {
        if (connexionBD.insertUtilisateur(name, password, mail)) {
            runOnUiThread(new Runnable() {
                public void run() {
                    Toast.makeText(getApplicationContext(), "Vous vous êtes inscris", Toast.LENGTH_SHORT).show();
                }
            });
            Intent intent = new Intent(this, Langue.class);
            User session = new User(name, password);
            intent.putExtra("session", session);
            startActivity(intent);
        }
    }
}
