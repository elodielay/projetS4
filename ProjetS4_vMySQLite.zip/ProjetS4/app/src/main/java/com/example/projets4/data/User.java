package com.example.projets4.data;

import android.os.Parcel;
import android.os.Parcelable;

public class User implements Parcelable {

    private String nom;
    private String mdp;

    public User(String nom, String mdp) {
        this.nom=nom;
        this.mdp=mdp;
    }

    protected User(Parcel in) {
        nom = in.readString();
        mdp = in.readString();
    }

    public static final Creator<User> CREATOR = new Creator<User>() {
        @Override
        public User createFromParcel(Parcel in) {
            return new User(in);
        }

        @Override
        public User[] newArray(int size) {
            return new User[size];
        }
    };

    public String getNom() {
        return this.nom;
    }

    public void setNom(String nom) {
        this.nom=nom;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(nom);
        dest.writeString(mdp);
    }
}
