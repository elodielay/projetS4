package com.example.projets4.data;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.projets4.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.Set;

public class Questions extends AppCompatActivity {

    private int idTheme;
    private DatabaseHelper connexionBD;
    private Map<String, String> mots;
    private String motPrecedent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_questions);

        Intent intent = getIntent();

        if (intent != null) {
            idTheme = intent.getIntExtra("idTheme",1);
        };

        this.motPrecedent = "";
        this.mots = new HashMap<>();
        this.connexionBD = new DatabaseHelper(this);

        try {
            remplirTableauMots().join();
        } catch (InterruptedException ie) {

        }

        nouvelleQuestion();

    }

    public Thread remplirTableauMots() {

        Thread m = new Thread() {
            @Override
            public void run() {
                Cursor res = connexionBD.getData("select * from Mot where theme_id = " + idTheme);

                while (res.moveToNext()) {
                        mots.put(res.getString(1), res.getString(2));
                }
            }
        };
        m.start();
        return m;
    }

    public void nouvelleQuestion() {
        TextView t = findViewById(R.id.phrasequestion);
        t.setTextSize(20);
        if (mots.size()>0) {
            Set<String> setMots = mots.keySet();
            ArrayList<String> contents = new ArrayList<>();
            for (String s : setMots) {
                contents.add(s);
            }
            Random r = new Random();

            String mot = contents.get(r.nextInt(contents.size()));

            if (mots.size()!=1) {
                while (mot.equals(motPrecedent)) {
                    mot = contents.get(r.nextInt(contents.size()));
                }
            }

            motPrecedent = mot;
            t.setText("Quelle est la traduction de " + mot);

            int nbAlea = 1 + (int) (Math.random() * ((2 - 1) + 1));
            typeQuestionAleatoire(nbAlea, mot);
        }
        else {
            t.setText("Ajoutez des mots pour pouvoir accéder aux questions !");
        }
    }

    public void typeQuestionAleatoire(int nombre, String mot) {
        LinearLayout layout = findViewById(R.id.viewquestion);
        layout.removeAllViews();
        switch(nombre) {
            case 1 :
                EditText e = new EditText(this);
                e.setHint("Insérez la traduction");
                layout.addView(e);
                FloatingActionButton valider = new FloatingActionButton(this);
                valider.setBackgroundTintList(ContextCompat.getColorStateList(getApplicationContext(), R.color.colorPrimaryDark));
                valider.setImageResource(R.drawable.valider);
                layout.addView(valider);
                valider.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String resultat = e.getText().toString();
                        afficheMessage(resultat, mot);
                    }
                });
                break;

            case 2 :
                LinearLayout Llayout = new LinearLayout(this);
                layout.addView(Llayout);
                Button choix1 = new Button(this);
                choix1.setWidth(60);
                Button choix2 = new Button(this);
                choix2.setWidth(60);
                choix1.setText(mots.get(mot));
                ArrayList<String> contents = new ArrayList<String>(mots.values());
                Random r = new Random();
                String fausseTrad = contents.get(r.nextInt(contents.size()));
                choix2.setText(fausseTrad);
                Llayout.addView(choix1);
                Llayout.addView(choix2);
                click(choix1, mot);
                click(choix2, mot);
                break;

        }
    }


    public void click(Button btn, String mot) {
        btn.setOnClickListener(new View.OnClickListener() {
            String resultat = btn.getText().toString();
            @Override
            public void onClick(View view) {
                afficheMessage(resultat, mot);
            }
        });
    }

    public void afficheMessage(String resultat, String mot) {
        if (resultat.equals(mots.get(mot))) {
            runOnUiThread(new Runnable() {
                public void run() {
                    Toast.makeText(getApplicationContext(), "Bonne réponse", Toast.LENGTH_SHORT).show();
                }
            });
        }
        else {
            runOnUiThread(new Runnable() {
                public void run() {
                    Toast.makeText(getApplicationContext(), "Mauvaise réponse", Toast.LENGTH_SHORT).show();
                }
            });
        }
        nouvelleQuestion();
    }
}
