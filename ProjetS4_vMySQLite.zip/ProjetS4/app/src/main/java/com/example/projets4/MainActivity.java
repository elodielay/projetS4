package com.example.projets4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.projets4.data.Register;
import com.example.projets4.ui.login.LoginActivity;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder()
                .detectDiskReads()
                .detectDiskWrites()
                .detectNetwork()
                .penaltyLog()
                .build());

        StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder()
                .detectLeakedSqlLiteObjects()
                .penaltyLog()
                .penaltyDeath()
                .build());


        Button boutonInscription = findViewById(R.id.buttonInscription);
        Button boutonConnexion = findViewById(R.id.buttonConnexion);

        boutonInscription.setOnClickListener(this);
        boutonConnexion.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

        switch(v.getId()) {

            case R.id.buttonInscription :
                startActivity(new Intent(MainActivity.this, Register.class));
                break;

            case R.id.buttonConnexion :
                startActivity(new Intent(MainActivity.this, LoginActivity.class));
                break;
        }
    }
}

